//
//  Model.swift
//  HW4
//
//  Created by CDMStudent on 2/25/24.
//

import Foundation

class DataModel{
    static var shared = DataModel()
    var segment : Int = 1
    var text : String = "Star Sports"
    var ChanNo : Int = 1
}
